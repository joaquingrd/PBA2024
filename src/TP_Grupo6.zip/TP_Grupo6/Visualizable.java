
package TP_Grupo6;


public interface Visualizable {
    public int tiempoVisto();
    public int ponerCalificacion();
    
}
